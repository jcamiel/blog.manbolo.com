//
//  CMViewController.m
//  TestModal
//
//  Created by Jean-Christophe Amiel on 04/12/13.
//  Copyright (c) 2013 Manbolo. All rights reserved.
//

#import "CMViewController.h"


@implementation CMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(applicationDidEnterBackground:)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIApplicationDidEnterBackgroundNotification
                                                  object:nil];
    
}

- (IBAction)tap:(id)sender
{
    self.alertView = [[UIAlertView alloc] initWithTitle:@"Hello"
                                                message:@"A standard UIAlertView"
                                               delegate:nil
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles:nil];
    [self.alertView show];
}

- (void)applicationDidEnterBackground:(NSNotification *)theNotification
{
    NSInteger cancelButtonIndex = self.alertView.cancelButtonIndex;
    [self.alertView dismissWithClickedButtonIndex:cancelButtonIndex
                                         animated:NO];
}

@end
