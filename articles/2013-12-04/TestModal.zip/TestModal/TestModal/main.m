//
//  main.m
//  TestModal
//
//  Created by Jean-Christophe Amiel on 04/12/13.
//  Copyright (c) 2013 Manbolo. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CMAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CMAppDelegate class]));
    }
}
