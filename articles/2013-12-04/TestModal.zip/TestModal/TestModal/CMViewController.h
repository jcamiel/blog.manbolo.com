//
//  CMViewController.h
//  TestModal
//
//  Created by Jean-Christophe Amiel on 04/12/13.
//  Copyright (c) 2013 Manbolo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMViewController : UIViewController

@property(nonatomic, strong) UIAlertView *alertView;

@end
