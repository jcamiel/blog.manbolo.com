//
//  CMAppDelegate.h
//  TestModal
//
//  Created by Jean-Christophe Amiel on 04/12/13.
//  Copyright (c) 2013 Manbolo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
